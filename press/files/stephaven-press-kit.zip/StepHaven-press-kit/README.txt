StepHaven press kit
A cozy town builder for iPhone where the only currency is the steps you walk.

fact sheet:   stephaven-fact-sheet.pdf
art:          high-resolution captures with no interface (free to use in coverage of StepHaven)
screenshots:  the App Store screenshots
video:        the 30-second App Store preview
icon:         1024 px app icon
events:       in-app event art from October 2026

Online:  https://stephaven.app/press/
App:     https://apps.apple.com/app/id6817135263
Contact: Brody Richmond, northlaneapps@gmail.com (StepHaven+ review codes on request)
